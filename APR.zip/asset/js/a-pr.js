$(document).ready(function() {
    $('.categories ul li').addClass('col-sm-4');
    $('.categories ul li a').append($("<span class='button'></span>"));
});
