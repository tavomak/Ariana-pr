<aside class="sidebar">
	<?php tha_sidebar_top(); ?>
	<?php dynamic_sidebar('sidebar-widget-area'); ?>
	<?php tha_sidebar_bottom(); ?>
</aside>
